# encoding: utf-8
# module Crypto.Hash._MD2
# from /usr/lib/python3/dist-packages/Crypto/Hash/_MD2.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

block_size = 64

digest_size = 16

# functions

def new(string=None): # real signature unknown; restored from __doc__
    """ new([string]): Return a new _MD2 hashing object.  An optional string argument may be provided; if present, this string will be automatically hashed into the initial state of the object. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb7335acf8>'

__spec__ = None # (!) real value is "ModuleSpec(name='Crypto.Hash._MD2', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb7335acf8>, origin='/usr/lib/python3/dist-packages/Crypto/Hash/_MD2.cpython-36m-x86_64-linux-gnu.so')"


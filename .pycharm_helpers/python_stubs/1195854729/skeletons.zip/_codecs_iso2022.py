# encoding: utf-8
# module _codecs_iso2022
# from /usr/lib/python3.6/lib-dynload/_codecs_iso2022.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb734429e8>'

__spec__ = None # (!) real value is "ModuleSpec(name='_codecs_iso2022', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb734429e8>, origin='/usr/lib/python3.6/lib-dynload/_codecs_iso2022.cpython-36m-x86_64-linux-gnu.so')"


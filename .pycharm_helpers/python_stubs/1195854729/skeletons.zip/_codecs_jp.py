# encoding: utf-8
# module _codecs_jp
# from /usr/lib/python3.6/lib-dynload/_codecs_jp.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb734429e8>'

__map_cp932ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb73358030>'

__map_jisx0208 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314180>'

__map_jisx0212 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314150>'

__map_jisx0213_1_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb723142a0>'

__map_jisx0213_1_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314de0>'

__map_jisx0213_2_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314c00>'

__map_jisx0213_2_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314e10>'

__map_jisx0213_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314d50>'

__map_jisx0213_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314e70>'

__map_jisx0213_pair = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314e40>'

__map_jisxcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fcb72314270>'

__spec__ = None # (!) real value is "ModuleSpec(name='_codecs_jp', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb734429e8>, origin='/usr/lib/python3.6/lib-dynload/_codecs_jp.cpython-36m-x86_64-linux-gnu.so')"


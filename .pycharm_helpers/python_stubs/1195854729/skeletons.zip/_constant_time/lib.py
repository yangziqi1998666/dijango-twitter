# encoding: utf-8
# module _constant_time.lib
# from /usr/lib/python3/dist-packages/cryptography/hazmat/bindings/_constant_time.abi3.so
# by generator 1.147
# no doc
# no imports

# functions

def Cryptography_constant_time_bytes_eq(uint8_t, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    uint8_t Cryptography_constant_time_bytes_eq(uint8_t *, size_t, uint8_t *, size_t);
    
    CFFI C function from _constant_time.lib
    """
    pass

# no classes

# encoding: utf-8
# module _testimportmultiple
# from /usr/lib/python3.6/lib-dynload/_testimportmultiple.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
""" _testimportmultiple doc """
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb734429e8>'

__spec__ = None # (!) real value is "ModuleSpec(name='_testimportmultiple', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fcb734429e8>, origin='/usr/lib/python3.6/lib-dynload/_testimportmultiple.cpython-36m-x86_64-linux-gnu.so')"


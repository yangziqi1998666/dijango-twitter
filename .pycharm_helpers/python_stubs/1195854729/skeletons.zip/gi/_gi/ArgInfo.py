# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
from gobject import (GBoxed, GEnum, GFlags, GInterface, GParamSpec, GPointer, 
    GType, Warning)

import gi as __gi
import gobject as __gobject


class ArgInfo(__gi.BaseInfo):
    # no doc
    def get_closure(self, *args, **kwargs): # real signature unknown
        pass

    def get_destroy(self, *args, **kwargs): # real signature unknown
        pass

    def get_direction(self, *args, **kwargs): # real signature unknown
        pass

    def get_ownership_transfer(self, *args, **kwargs): # real signature unknown
        pass

    def get_scope(self, *args, **kwargs): # real signature unknown
        pass

    def get_type(self, *args, **kwargs): # real signature unknown
        pass

    def is_caller_allocates(self, *args, **kwargs): # real signature unknown
        pass

    def is_optional(self, *args, **kwargs): # real signature unknown
        pass

    def is_return_value(self, *args, **kwargs): # real signature unknown
        pass

    def may_be_null(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass



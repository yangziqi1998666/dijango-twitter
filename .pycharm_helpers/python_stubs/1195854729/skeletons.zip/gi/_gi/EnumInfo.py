# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
from gobject import (GBoxed, GEnum, GFlags, GInterface, GParamSpec, GPointer, 
    GType, Warning)

import gi as __gi
import gobject as __gobject


class EnumInfo(__gi.RegisteredTypeInfo):
    # no doc
    def get_methods(self, *args, **kwargs): # real signature unknown
        pass

    def get_storage_type(self, *args, **kwargs): # real signature unknown
        pass

    def get_values(self, *args, **kwargs): # real signature unknown
        pass

    def is_flags(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass



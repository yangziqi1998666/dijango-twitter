# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
from gobject import (GBoxed, GEnum, GFlags, GInterface, GParamSpec, GPointer, 
    GType, Warning)

import gi as __gi
import gobject as __gobject


from .type import type

class InfoType(type):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    ARG = 17
    BOXED = 4
    CALLBACK = 2
    CONSTANT = 9
    ENUM = 5
    FIELD = 16
    FLAGS = 6
    FUNCTION = 1
    INTERFACE = 8
    INVALID = 0
    INVALID_0 = 10
    OBJECT = 7
    PROPERTY = 15
    SIGNAL = 13
    STRUCT = 3
    TYPE = 18
    UNION = 11
    UNRESOLVED = 19
    VALUE = 12
    VFUNC = 14



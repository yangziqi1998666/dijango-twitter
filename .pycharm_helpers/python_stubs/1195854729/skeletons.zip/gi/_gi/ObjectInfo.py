# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
from gobject import (GBoxed, GEnum, GFlags, GInterface, GParamSpec, GPointer, 
    GType, Warning)

import gi as __gi
import gobject as __gobject


class ObjectInfo(__gi.RegisteredTypeInfo):
    # no doc
    def find_method(self, *args, **kwargs): # real signature unknown
        pass

    def find_vfunc(self, *args, **kwargs): # real signature unknown
        pass

    def get_abstract(self, *args, **kwargs): # real signature unknown
        pass

    def get_class_struct(self, *args, **kwargs): # real signature unknown
        pass

    def get_constants(self, *args, **kwargs): # real signature unknown
        pass

    def get_fields(self, *args, **kwargs): # real signature unknown
        pass

    def get_fundamental(self, *args, **kwargs): # real signature unknown
        pass

    def get_get_value_function(self, *args, **kwargs): # real signature unknown
        pass

    def get_interfaces(self, *args, **kwargs): # real signature unknown
        pass

    def get_methods(self, *args, **kwargs): # real signature unknown
        pass

    def get_parent(self, *args, **kwargs): # real signature unknown
        pass

    def get_properties(self, *args, **kwargs): # real signature unknown
        pass

    def get_ref_function(self, *args, **kwargs): # real signature unknown
        pass

    def get_set_value_function(self, *args, **kwargs): # real signature unknown
        pass

    def get_signals(self, *args, **kwargs): # real signature unknown
        pass

    def get_type_init(self, *args, **kwargs): # real signature unknown
        pass

    def get_type_name(self, *args, **kwargs): # real signature unknown
        pass

    def get_unref_function(self, *args, **kwargs): # real signature unknown
        pass

    def get_vfuncs(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass



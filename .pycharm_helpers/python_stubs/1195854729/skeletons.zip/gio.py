# encoding: utf-8
# module gio
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
""" When using gi.repository you must not import static modules like "gobject". Please change all occurrences of "import gobject" to "from gi.repository import GObject". See: https://bugzilla.gnome.org/show_bug.cgi?id=709183 """
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# no classes
